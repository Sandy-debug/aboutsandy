package com.example.vault

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

private data class LoginEntry(val title: String, val username: String, val password: String, val url: String, val notes: String = "")

class MainActivity : ComponentActivity() {
    private lateinit var crypto: CryptoVault
    private lateinit var biometricStore: BiometricMasterStore
    private val mainHandler = Handler(Looper.getMainLooper())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        crypto = CryptoVault(filesDir.resolve("vault.bin")); biometricStore = BiometricMasterStore(this)
        setContent { MaterialTheme { VaultScreen(crypto, biometricStore, ::showBiometricPrompt, ::copySecret, ::clearClipboard) } }
    }
    private fun showBiometricPrompt(cipher: javax.crypto.Cipher, title: String, onSuccess: (BiometricPrompt.CryptoObject) -> Unit, onError: (String) -> Unit) {
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { result.cryptoObject?.let(onSuccess) ?: onError("Biometric operation failed.") }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onError(errString.toString()) }
            override fun onAuthenticationFailed() { /* Prompt remains available for another attempt. */ }
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle(title).setSubtitle("Authenticate on this device").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).setNegativeButtonText("Cancel").build(), BiometricPrompt.CryptoObject(cipher))
    }
    private fun copySecret(value: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Password", value))
        mainHandler.postDelayed({ try { if (clipboard.hasPrimaryClip() && clipboard.primaryClip?.getItemAt(0)?.text?.toString() == value) clipboard.clearPrimaryClip() } catch (_: Exception) {} }, 30_000)
    }
    private fun clearClipboard() { try { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).clearPrimaryClip() } catch (_: Exception) {} }
}

@Composable
private fun VaultScreen(
    crypto: CryptoVault,
    biometricStore: BiometricMasterStore,
    showBiometricPrompt: (javax.crypto.Cipher, String, (BiometricPrompt.CryptoObject) -> Unit, (String) -> Unit) -> Unit,
    copySecret: (String) -> Unit,
    clearClipboard: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var master by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(false) }
    var needsSetup by remember { mutableStateOf(!crypto.exists()) }
    var message by remember { mutableStateOf("Offline vault • encrypted on this phone only") }
    var search by remember { mutableStateOf("") }
    var entries by remember { mutableStateOf(listOf<LoginEntry>()) }
    var showAdd by remember { mutableStateOf(false) }
    var editIndex by remember { mutableStateOf<Int?>(null) }
    var revealed by remember { mutableStateOf(setOf<Int>()) }
    var autoLockSeconds by remember { mutableIntStateOf(60) }
    var showGenerator by remember { mutableStateOf(false) }
    var generatedPassword by remember { mutableStateOf("") }
    var clipboardNotice by remember { mutableStateOf(false) }

    fun encode(items: List<LoginEntry>) = JSONArray().apply { items.forEach { put(JSONObject().put("title",it.title).put("username",it.username).put("password",it.password).put("url",it.url).put("notes",it.notes)) } }.toString().toByteArray(Charsets.UTF_8)
    fun decode(bytes: ByteArray): List<LoginEntry> { val a = JSONArray(String(bytes, Charsets.UTF_8)); return (0 until a.length()).map { i -> a.getJSONObject(i).let { LoginEntry(it.optString("title"),it.optString("username"),it.optString("password"),it.optString("url"),it.optString("notes")) } } }
    fun save(items: List<LoginEntry>) { crypto.create(master.toCharArray(), encode(items)); entries = items }
    fun lock() { clearClipboard(); master = ""; entries = emptyList(); revealed = emptySet(); unlocked = false; message = "Vault locked." }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) try { context.contentResolver.openOutputStream(uri)?.use { it.write(crypto.encryptedBytes()) }; message = "Encrypted backup exported. Keep it private; it can be attacked offline if your master password is weak." } catch (e: Exception) { message = "Backup export failed: ${e.message}" }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Could not read backup")
            val restored = decode(crypto.verifyEncryptedBackup(bytes, master.toCharArray()))
            crypto.replaceEncryptedBackup(bytes)
            entries = restored
            message = "Encrypted backup restored and verified."
        } catch (e: Exception) { message = e.message ?: "Backup restore failed." }
    }
    DisposableEffect(lifecycleOwner, unlocked, autoLockSeconds) {
        var backgroundAt = 0L
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && unlocked) backgroundAt = System.currentTimeMillis()
            if (event == Lifecycle.Event.ON_START && unlocked && backgroundAt > 0 && System.currentTimeMillis() - backgroundAt >= autoLockSeconds * 1000L) lock()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("VAULT", style = MaterialTheme.typography.headlineLarge)
        Text("Private password manager", style = MaterialTheme.typography.titleMedium)
        if (!unlocked) {
            Text(if (needsSetup) "Create your master password" else "Unlock your vault")
            OutlinedTextField(master, { master = it }, label = { Text("Master password") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), singleLine = true, modifier = Modifier.fillMaxWidth())
            if (needsSetup) Text("Use at least 12 characters; a long unique passphrase is better.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = {
                try {
                    if (needsSetup) { save(emptyList()); needsSetup = false; unlocked = true; message = "Vault created. Your master password cannot be reset." }
                    else { entries = decode(crypto.unlock(master.toCharArray())); unlocked = true; message = "Vault unlocked." }
                } catch (e: Exception) { message = e.message ?: "Could not open vault." }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (needsSetup) "Create encrypted vault" else "Unlock") }
            if (!needsSetup && biometricStore.isEnabled()) OutlinedButton(onClick = {
                try { showBiometricPrompt(biometricStore.decryptCipher(), "Unlock Vault with biometrics", { result ->
                    try { val bioMaster = biometricStore.decryptMaster(result.cipher!!); master = String(bioMaster); entries = decode(crypto.unlock(bioMaster)); unlocked = true; message = "Vault unlocked with biometrics."; bioMaster.fill('\u0000') }
                    catch (e: Exception) { message = "Biometric unlock failed. Use your master password." }
                }, { message = it }) } catch (e: Exception) { message = "Biometric unlock unavailable. Use your master password." }
            }, modifier = Modifier.fillMaxWidth()) { Text("Unlock with fingerprint") }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exportLauncher.launch("vault-backup.vlt") }, modifier = Modifier.weight(1f)) { Text("Export backup") }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("Restore backup") }
            }
            if (!biometricStore.isEnabled()) OutlinedButton(onClick = {
                try { showBiometricPrompt(biometricStore.encryptCipher(), "Enable fingerprint unlock", { result ->
                    try { biometricStore.saveEncrypted(result.cipher!!, master.toCharArray()); message = "Fingerprint unlock enabled." } catch (e: Exception) { message = "Could not enable biometrics: ${e.message}" }
                }, { message = it }) } catch (e: Exception) { message = "Biometrics unavailable: ${e.message}" }
            }, modifier = Modifier.fillMaxWidth()) { Text("Enable fingerprint unlock") }
            else OutlinedButton(onClick = { biometricStore.disable(); message = "Fingerprint unlock disabled." }, modifier = Modifier.fillMaxWidth()) { Text("Disable fingerprint unlock") }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Auto-lock", modifier = Modifier.weight(1f))
                listOf(0, 30, 60, 300).forEach { seconds -> FilterChip(selected = autoLockSeconds == seconds, onClick = { autoLockSeconds = seconds }, label = { Text(if (seconds == 0) "Never" else if (seconds < 60) "30s" else if (seconds == 60) "1m" else "5m") }) }
            }
            OutlinedTextField(search, { search = it }, label = { Text("Search entries") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { editIndex = null; showAdd = true }, modifier = Modifier.weight(1f)) { Text("＋ Add login") }
                OutlinedButton(onClick = { showGenerator = true }, modifier = Modifier.weight(1f)) { Text("Password generator") }
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(entries.filter { it.title.contains(search, true) || it.username.contains(search, true) || it.url.contains(search, true) }) { _, e ->
                    val originalIndex = entries.indexOf(e)
                    var showDetails by remember(e.title, e.username) { mutableStateOf(false) }
                    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(e.title, style = MaterialTheme.typography.titleMedium)
                        if (e.username.isNotBlank()) Text(e.username)
                        Text(if (originalIndex in revealed) e.password else "Password: ••••••••")
                        if (e.url.isNotBlank()) Text(e.url, style = MaterialTheme.typography.bodySmall)
                        if (showDetails && e.notes.isNotBlank()) Text("Notes: ${e.notes}")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = { revealed = if (originalIndex in revealed) revealed - originalIndex else revealed + originalIndex }) { Text(if (originalIndex in revealed) "Hide" else "Reveal") }
                            TextButton(onClick = { copySecret(e.password); clipboardNotice = true; message = "Password copied; clipboard clears after 30 seconds." }) { Text("Copy password") }
                            TextButton(onClick = { copySecret(e.username); message = "Username copied; clipboard clears after 30 seconds." }) { Text("Copy username") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = { showDetails = !showDetails }) { Text(if (showDetails) "Hide notes" else "Notes") }
                            TextButton(onClick = { editIndex = originalIndex; showAdd = true }) { Text("Edit") }
                            TextButton(onClick = { save(entries.filterIndexed { index, _ -> index != originalIndex }); message = "Entry deleted." }) { Text("Delete") }
                        }
                    } }
                }
            }
            OutlinedButton(onClick = { lock() }, modifier = Modifier.fillMaxWidth()) { Text("Lock vault now") }
        }
        Text(message, style = MaterialTheme.typography.bodySmall)
    }
    if (showAdd) {
        val current = editIndex?.let { entries.getOrNull(it) }
        EntryDialog(initial = current, onDismiss = { showAdd = false; editIndex = null }, onSave = { entry ->
            try { val updated = if (editIndex == null) entries + entry else entries.toMutableList().also { it[editIndex!!] = entry }; save(updated); showAdd = false; editIndex = null; message = "Entry saved encrypted." }
            catch (e: Exception) { message = "Save failed: ${e.message}" }
        })
    }
    if (showGenerator) AlertDialog(onDismissRequest = { showGenerator = false }, title = { Text("Password generator") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (generatedPassword.isNotBlank()) Text(generatedPassword, style = MaterialTheme.typography.bodyLarge)
            Text("Creates a random 24-character password using the device secure random generator.")
            OutlinedButton(onClick = { generatedPassword = generatePassword() }, modifier = Modifier.fillMaxWidth()) { Text("Generate") }
            if (generatedPassword.isNotBlank()) OutlinedButton(onClick = { copySecret(generatedPassword); message = "Generated password copied; clipboard clears after 30 seconds." }, modifier = Modifier.fillMaxWidth()) { Text("Copy password") }
        }
    }, confirmButton = { TextButton(onClick = { generatedPassword = ""; showGenerator = false }) { Text("Close") } })
}

private fun generatePassword(length: Int = 24): String {
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%_-+=?"
    val random = SecureRandom()
    return buildString { repeat(length) { append(chars[random.nextInt(chars.length)]) } }
}

@Composable
private fun EntryDialog(initial: LoginEntry?, onDismiss: () -> Unit, onSave: (LoginEntry) -> Unit) {
    var title by remember(initial) { mutableStateOf(initial?.title ?: "") }
    var username by remember(initial) { mutableStateOf(initial?.username ?: "") }
    var password by remember(initial) { mutableStateOf(initial?.password ?: "") }
    var url by remember(initial) { mutableStateOf(initial?.url ?: "") }
    var notes by remember(initial) { mutableStateOf(initial?.notes ?: "") }
    var reveal by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initial == null) "Add login" else "Edit login") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Service / website *") }, singleLine = true)
            OutlinedTextField(username, { username = it }, label = { Text("Username / email") }, singleLine = true)
            OutlinedTextField(password, { password = it }, label = { Text("Password *") }, visualTransformation = if (reveal) VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { reveal = !reveal }) { Text(if (reveal) "Hide" else "Show") } }, singleLine = true)
            OutlinedTextField(url, { url = it }, label = { Text("Website (optional)") }, singleLine = true)
            OutlinedTextField(notes, { notes = it }, label = { Text("Secure notes (optional)") }, minLines = 2)
        }
    }, confirmButton = { TextButton(onClick = { if (title.isNotBlank() && password.isNotBlank()) onSave(LoginEntry(title.trim(),username,password,url,notes)) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
