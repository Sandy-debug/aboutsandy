package com.example.vault

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.os.Build
import android.os.Build.VERSION_CODES
import androidx.biometric.BiometricPrompt
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Optional biometric convenience: the master password is wrapped by a per-use, biometric-gated Keystore key. */
class BiometricMasterStore(context: Context) {
    private val prefs = context.getSharedPreferences("biometric_unlock", Context.MODE_PRIVATE)
    private val alias = "vault_biometric_wrap_v1"
    fun isEnabled() = prefs.contains("ciphertext") && prefs.contains("iv")
    fun disable() { prefs.edit().clear().apply(); try { val ks = java.security.KeyStore.getInstance("AndroidKeyStore"); ks.load(null); if (ks.containsAlias(alias)) ks.deleteEntry(alias) } catch (_: Exception) {} }
    fun encryptCipher(): Cipher = cipher(Cipher.ENCRYPT_MODE)
    fun decryptCipher(): Cipher {
        val iv = Base64.decode(prefs.getString("iv", "") ?: "", Base64.NO_WRAP)
        return cipher(Cipher.DECRYPT_MODE, iv)
    }
    fun saveEncrypted(cipher: Cipher, master: CharArray) {
        val bytes = String(master).toByteArray(Charsets.UTF_8)
        try {
            val encrypted = cipher.doFinal(bytes)
            prefs.edit().putString("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).putString("ciphertext", Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply()
        } finally { bytes.fill(0) }
    }
    fun decryptMaster(cipher: Cipher): CharArray {
        val encrypted = Base64.decode(prefs.getString("ciphertext", "") ?: "", Base64.NO_WRAP)
        val bytes = cipher.doFinal(encrypted)
        return try { String(bytes, Charsets.UTF_8).toCharArray() } finally { bytes.fill(0) }
    }
    private fun cipher(mode: Int, iv: ByteArray? = null): Cipher {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore"); ks.load(null)
        var key = ks.getKey(alias, null) as? SecretKey
        if (key == null) {
            val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            val builder = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setUserAuthenticationRequired(true).setInvalidatedByBiometricEnrollment(true)
            if (Build.VERSION.SDK_INT >= VERSION_CODES.R) {
                builder.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
            }
            generator.init(builder.build())
            key = generator.generateKey()
        }
        return Cipher.getInstance("AES/GCM/NoPadding").also { if (iv == null) it.init(mode, key) else it.init(mode, key, GCMParameterSpec(128, iv)) }
    }
}
