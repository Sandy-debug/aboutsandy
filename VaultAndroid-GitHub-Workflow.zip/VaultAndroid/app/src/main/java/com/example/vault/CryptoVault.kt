package com.example.vault

import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Local-only encrypted vault. Format: VLT2 || salt(16) || nonce(12) || AES-GCM ciphertext. */
class CryptoVault(private val file: File) {
    private val random = SecureRandom()
    private val magic = "VLT2".toByteArray(Charsets.US_ASCII)
    fun exists() = file.exists()
    fun create(masterPassword: CharArray, plaintext: ByteArray) {
        require(masterPassword.size >= 12) { "Use a master password of at least 12 characters." }
        val salt = ByteArray(16).also(random::nextBytes)
        val nonce = ByteArray(12).also(random::nextBytes)
        val key = derive(masterPassword, salt)
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            cipher.updateAAD(magic)
            val bytes = magic + salt + nonce + cipher.doFinal(plaintext)
            file.parentFile?.mkdirs()
            val temp = File(file.parentFile, file.name + ".tmp")
            temp.writeBytes(bytes)
            temp.setReadable(false, false); temp.setReadable(true, true)
            temp.setWritable(false, false); temp.setWritable(true, true)
            try { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
            catch (e: Exception) { temp.delete(); throw IllegalStateException("Could not safely finalize vault file.", e) }
        } finally { key.fill(0) }
    }
    fun unlock(masterPassword: CharArray): ByteArray {
        val bytes = file.readBytes()
        require(bytes.size > 48 && bytes.copyOfRange(0, 4).contentEquals(magic)) { "Vault file is invalid or uses an unsupported format." }
        val salt = bytes.copyOfRange(4, 20); val nonce = bytes.copyOfRange(20, 32); val ciphertext = bytes.copyOfRange(32, bytes.size)
        val key = derive(masterPassword, salt)
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce)); cipher.updateAAD(magic)
            cipher.doFinal(ciphertext)
        } catch (_: Exception) { throw IllegalArgumentException("Wrong master password or damaged vault.") }
        finally { key.fill(0) }
    }
    fun verifyEncryptedBackup(bytes: ByteArray, masterPassword: CharArray): ByteArray {
        require(bytes.size > 48 && bytes.copyOfRange(0, 4).contentEquals(magic)) { "This is not a supported encrypted Vault backup." }
        val salt = bytes.copyOfRange(4, 20); val nonce = bytes.copyOfRange(20, 32); val ciphertext = bytes.copyOfRange(32, bytes.size)
        val key = derive(masterPassword, salt)
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce)); cipher.updateAAD(magic)
            cipher.doFinal(ciphertext)
        } catch (_: Exception) { throw IllegalArgumentException("Backup does not match this master password or is damaged.") }
        finally { key.fill(0) }
    }
    fun replaceEncryptedBackup(bytes: ByteArray) {
        require(bytes.size > 48 && bytes.copyOfRange(0, 4).contentEquals(magic)) { "This is not a supported encrypted Vault backup." }
        val temp = File(file.parentFile, file.name + ".import")
        temp.writeBytes(bytes)
        try { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
        catch (e: Exception) { temp.delete(); throw IllegalStateException("Could not safely restore backup.", e) }
    }
    fun encryptedBytes() = file.readBytes()
    private fun derive(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, 600_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }
}
