# Vault Android — offline password manager prototype

Native Android / Kotlin / Jetpack Compose. Designed to work only on the phone: no Internet permission, no cloud account, no analytics or advertising SDKs.

## Implemented in this prototype
- Master-password setup and unlock; minimum 12 characters.
- AES-256-GCM authenticated encryption with PBKDF2-HMAC-SHA256 (600,000 iterations), random salt and nonce.
- Private app storage and atomic replacement of vault/backup files.
- Add, edit, delete, search, reveal/hide, username/password copy, and secure notes.
- Password generation using `SecureRandom`.
- Optional biometric unlock using an Android Keystore AES key requiring strong biometric authentication; master password is stored only as authenticated encrypted data for this opt-in feature.
- Clipboard auto-clear after 30 seconds, plus clearing on lock.
- App screenshot/recents blocking (`FLAG_SECURE`).
- Configurable lock-on-return timeout (30 seconds, 1 minute, 5 minutes, or never).
- Encrypted backup export and restore. The backup remains encrypted and is verified against the current master password before replacing the vault.
- Android backup disabled; no Internet permission declared.

## Open and run
1. Install Android Studio stable and Android SDK 35.
2. Open this folder in Android Studio and let Gradle sync.
3. Run on an Android 8.0+ device. Biometric unlock requires compatible strong biometrics and secure device enrollment.

## Important security caveats
This is a feature-complete prototype, **not an audited production password manager**. It has not been compiled, device-tested, fuzzed, or independently security-reviewed in this environment. Do not put real credentials in it until it passes build, unit, instrumentation, and security testing by a qualified reviewer.

- JVM `String`/Compose state cannot be reliably wiped from memory. Locking clears app state as best effort but cannot guarantee secure erasure.
- Auto-lock is enforced when returning to the app after the configured background interval; it is not a guarantee against a compromised/rooted device.
- The biometric feature is a convenience unlock, not a replacement for a strong master password. Biometric enrollment changes can invalidate its Keystore key; use the master password in that case.
- Encrypted backups can be attacked offline. Use a long, unique master passphrase and store backup files securely.
- No password reset exists. If the master password is lost and biometric unlock is unavailable, the vault cannot be recovered.
- No Android Autofill service is included yet. Adding Autofill requires a separate, security-reviewed service and tests.
- Android clipboard managers, keyboards, accessibility services, rooted devices, malware, and OS vulnerabilities remain part of the threat model.
- The app intentionally uses a simple JSON payload inside the encrypted container. Review format migration, crash recovery, file permissions, and cryptographic implementation before release.
